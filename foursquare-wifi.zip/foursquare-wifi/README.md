# foursquare-wifi
Create a free Wifi map off the foursquare API and google maps API
